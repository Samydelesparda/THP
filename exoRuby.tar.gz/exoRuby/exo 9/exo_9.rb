print "whats your first name?"
first_name = gets.chomp
answer = gets.chomp
answer2 = answer.capitalize 
answer.capitalize!

print "whats your last name?"
last_name = gets.chomp
answer = gets.chomp
answer2 = answer.capitalize 
answer.capitalize!


puts "Your name is #{first_name}!""Your last name is #{last_name}!"