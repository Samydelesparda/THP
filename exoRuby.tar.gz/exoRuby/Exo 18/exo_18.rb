array = []
50.times do |i|
    chiffre = i + 1
      array << "jean.dupont.#{chiffre}@email.com"
end
print array