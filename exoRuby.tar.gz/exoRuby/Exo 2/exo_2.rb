print "Bonjour, monde !
Et avec une voix sexy, ça donne : Bonjour, monde !"