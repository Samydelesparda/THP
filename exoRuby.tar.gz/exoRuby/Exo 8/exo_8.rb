print "whats your first name?"
first_name = gets.chomp
answer = gets.chomp
answer2 = answer.capitalize 
answer.capitalize!

puts "Your name is #{first_name}!"