puts "Bonjour, c'est quoi ton blase ?"
print "> "
user_name = gets.chomp
puts user_name