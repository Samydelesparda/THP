puts "donne un number"
number = gets.chomp.to_i
number.downto(nombre_user){ |i| print i, " " }