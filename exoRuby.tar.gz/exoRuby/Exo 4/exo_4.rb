puts "salut ça farte?"
#Le terminale affiche salut ça farte, car "puts" affiche une nouvelle ligne