puts "quel est ton age"
year_of_birth = gets.chomp.to_i
year_of_birth.upto(nombre_user){ |i| print i, " " }