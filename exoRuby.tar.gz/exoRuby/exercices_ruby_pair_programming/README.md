# exercices_ruby_pair_programming
Exercices Ruby en Pair Programming
