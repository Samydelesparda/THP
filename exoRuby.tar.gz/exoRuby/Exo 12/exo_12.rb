puts "veuillez choisir un nombre"
nombre_user = gets.chomp.to_i
1.upto(nombre_user){ |i| print i, " " }