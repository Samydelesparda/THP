puts "bonjour, ton année de naissance stp?"
year_of_birth = get.chomp.to_i #to_i pour les valeurs numériques
puts "#{2017 - year_of_birth}" # #{} pour les valeurs variables
